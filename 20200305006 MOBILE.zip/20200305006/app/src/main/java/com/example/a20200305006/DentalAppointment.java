package com.example.a20200305006;

import java.util.Date;

public class DentalAppointment {
    private String patientName;
    private Date appointmentDate;
    private String appointmentTime;
    private String appointmentReason;

    public DentalAppointment(String patientName, Date appointmentDate, String appointmentTime, String appointmentReason) {
        this.patientName = patientName;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.appointmentReason = appointmentReason;
    }

    public String getPatientName() { return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getAppointmentReason() {
        return appointmentReason;
    }

    public void setAppointmentReason(String appointmentReason) {
        this.appointmentReason = appointmentReason;
    }
}