package com.example.a20200305006;

import java.util.ArrayList;
import java.util.List;

public class DentalAppointmentManager {
    private List<DentalAppointment> appointments;

    public DentalAppointmentManager() {
        this.appointments = new ArrayList<>();
    }

    public void addAppointment(DentalAppointment appointment) {
        appointments.add(appointment);
    }

    public void removeAppointment(DentalAppointment appointment) {
        appointments.remove(appointment);
    }

    public List<DentalAppointment> getAppointments() {
        return appointments;
    }
}